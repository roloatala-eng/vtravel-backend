# CHANGELOG — Vtravel Backend

## RC-BACKEND-01 — 14 de julio de 2026

### Agregado
- Base de datos (SQLite — ver README.md sobre por qué no PostgreSQL en este RC) con las tablas `vehiculos`, `clientes`, `cotizaciones`, `reservas`, `usuarios_admin`.
- API REST con 9 endpoints (health, auth/login, CRUD parcial de clientes/cotizaciones/reservas).
- Autenticación JWT real (HS256, implementado con `node:crypto`, sin librerías externas).
- Hash de contraseñas con `scrypt` + salt único.
- Rate limiting en memoria (30 req/min por IP).
- Sanitización básica de campos de texto.
- Script `seed-admin.js` para crear usuarios administradores.
- Conexión real entre el formulario del sitio (`js/main.js`) y la API, con fallback silencioso a WhatsApp si el backend no está desplegado — el sitio nunca se rompe por esto.

### Decisiones técnicas documentadas
- SQLite en vez de PostgreSQL, SQL directo en vez de Prisma — ambos por falta de acceso a internet en el entorno de desarrollo, no por elección de diseño. El schema de PostgreSQL de referencia sigue existiendo en `Vtravel_CRM_Diseño.zip`.
- Router HTTP hecho a mano en vez de Express, mismo motivo.

### No incluido en este RC (ver README.md, sección "Lo que NO está en este RC")
- Integración con Google Maps, CAPTCHA, despliegue con URL pública.
- RC-BACKEND-02 a 05 completos (dashboard visual, módulo financiero conectado, WhatsApp/pagos, optimización de carga).

## RC-BACKEND-02 — 14 de julio de 2026

### Agregado
- **Capa de repositorio** (`src/repository.js`): toda la lógica de negocio pasa por acá, ninguna ruta escribe SQL directo. Migrar a PostgreSQL más adelante significa cambiar este archivo, no las rutas.
- **Rutas modularizadas**: `server.js` pasó de un archivo único a un despachador liviano + módulos en `src/routes/` (auth, clientes, cotizaciones, reservas, dashboard).
- Endpoints nuevos: `PUT /api/reservas/:id/estado`, `/cancelar`, `/reprogramar`; `GET /api/dashboard/resumen`; búsqueda (`?q=`) y filtros (`?estado=`, `?hoy=`, `?futuras=`) en clientes y reservas.
- **Dashboard visual real** (`public/dashboard.html`) — login, tarjetas resumen, tabla de reservas con búsqueda/filtro/cambio de estado/cancelación, tabla de clientes con reservas calculadas.
- **Integración Brevo** (`src/email.js`) — código real y completo; sin `BREVO_API_KEY` loguea el correo en vez de fallar o fingir.
- Conexión completa desde el sitio real: el botón "Reservar Ahora" ahora crea cliente + cotización + reserva en el backend (antes solo llegaba hasta cotización), e incluye el número de reserva real en el mensaje de WhatsApp cuando el backend respondió.

### Eliminado
- Carpeta `src/routes/` vacía que había quedado sin usar del RC anterior.
- `src/server.js.bak` (respaldo temporal usado solo para verificar la migración sin pérdida de lógica).

### Verificado
- Prueba end-to-end real con Playwright: un "usuario" completando el sitio real de punta a punta, con los datos apareciendo en el Dashboard inmediatamente después. Ver `CHECKLIST_PRUEBAS.md`, prueba #12.

### Seguimos sin (mismo motivo de siempre — sin red saliente en este entorno)
- Envío real de emails vía Brevo (código listo, no probado con la API real).
- WhatsApp Business API (se sigue generando el mensaje listo, como pediste como alternativa).
- Migración real a PostgreSQL (diseño listo en `Vtravel_CRM_Diseño.zip`, capa de repositorio ya preparada para el cambio).
- Servidor con URL pública.
