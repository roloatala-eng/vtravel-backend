const repo = require('../repository');
const { enviarJSON } = require('../utils/http');

async function resumen(req, res) {
    enviarJSON(res, 200, await repo.resumenDashboard());
}

module.exports = { resumen };
