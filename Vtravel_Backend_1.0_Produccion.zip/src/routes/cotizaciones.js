const repo = require('../repository');
const { enviarJSON, leerCuerpo, sanitizarTexto } = require('../utils/http');

async function crear(req, res) {
    const body = await leerCuerpo(req);
    const requeridos = ['cliente_id', 'vehiculo_id', 'origen', 'destino', 'fecha_servicio', 'hora_servicio', 'tipo_servicio', 'distancia_km', 'pasajeros', 'precio_total'];
    for (const campo of requeridos) {
        if (body[campo] === undefined || body[campo] === null || body[campo] === '') {
            return enviarJSON(res, 400, { error: `Falta el campo: ${campo}` });
        }
    }
    const cotizacion = await repo.crearCotizacion({
        ...body,
        origen: sanitizarTexto(body.origen),
        destino: sanitizarTexto(body.destino),
    });
    enviarJSON(res, 201, cotizacion);
}

async function listar(req, res, url) {
    const estado = url.searchParams.get('estado');
    enviarJSON(res, 200, await repo.listarCotizaciones({ estado }));
}

module.exports = { crear, listar };
