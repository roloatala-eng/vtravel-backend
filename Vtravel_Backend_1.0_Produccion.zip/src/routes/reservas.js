const repo = require('../repository');
const { enviarCorreoConfirmacion } = require('../email');
const { enviarJSON, leerCuerpo } = require('../utils/http');

async function crear(req, res) {
    const body = await leerCuerpo(req);
    if (!body.cotizacion_id || !body.cliente_id || !body.pasajeros || !body.fecha_viaje || !body.hora_viaje) {
        return enviarJSON(res, 400, { error: 'Faltan campos requeridos' });
    }
    const reserva = await repo.crearReserva(body);
    const resultadoEmail = await enviarCorreoConfirmacion({
        ...reserva,
        cliente_email: reserva.cliente_email,
        cliente_nombre: reserva.cliente_nombre,
    });
    enviarJSON(res, 201, { ...reserva, email: resultadoEmail });
}

async function listar(req, res, url) {
    const estado = url.searchParams.get('estado');
    const busqueda = url.searchParams.get('q');
    const soloHoy = url.searchParams.get('hoy') === 'true';
    const soloFuturas = url.searchParams.get('futuras') === 'true';
    enviarJSON(res, 200, await repo.listarReservas({ estado, busqueda, soloHoy, soloFuturas }));
}

async function obtener(req, res, id) {
    const reserva = await repo.obtenerReserva(id);
    if (!reserva) return enviarJSON(res, 404, { error: 'No encontrada' });
    enviarJSON(res, 200, reserva);
}

async function actualizarEstado(req, res, id) {
    const body = await leerCuerpo(req);
    try {
        const reserva = await repo.actualizarEstadoReserva(id, body.estado);
        if (!reserva) return enviarJSON(res, 404, { error: 'No encontrada' });
        enviarJSON(res, 200, reserva);
    } catch (err) {
        enviarJSON(res, 400, { error: err.message });
    }
}

async function cancelar(req, res, id) {
    const reserva = await repo.actualizarEstadoReserva(id, 'cancelada');
    if (!reserva) return enviarJSON(res, 404, { error: 'No encontrada' });
    enviarJSON(res, 200, reserva);
}

async function reprogramar(req, res, id) {
    const body = await leerCuerpo(req);
    if (!body.fecha_viaje || !body.hora_viaje) {
        return enviarJSON(res, 400, { error: 'Faltan fecha_viaje / hora_viaje' });
    }
    const reserva = await repo.reprogramarReserva(id, body);
    if (!reserva) return enviarJSON(res, 404, { error: 'No encontrada' });
    enviarJSON(res, 200, reserva);
}

module.exports = { crear, listar, obtener, actualizarEstado, cancelar, reprogramar };
