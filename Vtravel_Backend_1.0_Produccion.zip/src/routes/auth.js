const db = require('../db');
const { firmar, verificarPassword } = require('../auth');
const { enviarJSON, leerCuerpo } = require('../utils/http');

async function login(req, res) {
    const { email, password } = await leerCuerpo(req);
    const { rows } = await db.query('SELECT * FROM usuarios_admin WHERE email = ?', [email]);
    const usuario = rows[0];
    if (!usuario || !verificarPassword(password, usuario.password_hash, usuario.password_salt)) {
        return enviarJSON(res, 401, { error: 'Credenciales inválidas' });
    }
    const token = firmar({ sub: usuario.id, email: usuario.email });
    enviarJSON(res, 200, { token });
}

module.exports = { login };
